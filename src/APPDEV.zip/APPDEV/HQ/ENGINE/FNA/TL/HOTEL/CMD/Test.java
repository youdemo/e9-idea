package APPDEV.HQ.ENGINE.FNA.TL.HOTEL.CMD;

import com.api.cowork.service.CoworkBaseService;
import com.ctrip.ecology.SetApprovalAction;

import java.util.UUID;

public class Test {
    public static void main(String[] args){
        System.out.println(UUID.randomUUID().toString());
    }
}
